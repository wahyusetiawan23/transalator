<?php 
// indonesia
$newdata = array (
    'header_one' => 'Apa Itu RBM. ?',
    'header_two' => 'RBM (Repair Business Management) adalah 
    aplikasi berbasis website untuk rekap service, 
    managemen sparepart, tracking service untuk konsumen. dan Juga dilengkapi dengan 
    marketing tools, landing page untuk kebutuhan branding usaha service smartphone.
    ',
    'button_header' => 'Registrasi',


    'header_card_one' => 'Cara Mendapatkan Token',
    'desc_header_search' => '1. Cari Reseller',
    'desc_header_contact' => '2. Hubungi No. Telepon',


    'header_card_two' => 'Cara Mendaftar Reseller',
    'desc_header_admin' => '1. Hubungi No. Telepon Admin',
    'desc_header_format' => '2. Kirim Format Whatsapp (rbm_reseller # namaowner # namatoko # no.telepon # alamat)',


    'header_feature' => 'Fitur Mobi App Untuk Owner Toko',


    'feature_desc_home' => 'Laba Bulanan',
    'feature_card_one' => 'Laporan Harian',
    'feature_desc_service' => 'Laporan Laba service',
    'feature_desc_phone' => 'Laporan Laba Handphone',
    'feature_desc_part' => 'Laporan Laba Sparepart',
    'feature_card_two' => 'Pegawai',
    'feature_desc_admin' => 'Kelola Admin',
    'feature_card_three' => 'Kelola Toko',
    'feature_desc_store' => 'Persentase, Banner, Garansi',


    'header_started' => 'Mulai',


    'header_footer' => 'Info Lebih Lanjut',

);
return ($newdata);

// Inggris
$newdata = array (
    'header_one' => 'What Is RBM. ?',
    'header_two' => 'RBM (Repair Business Management) is a website-based application for service recap, spare parts management, tracking service for consumers. and also equipped with marketing tools, landing pages branding for smartphone service businesses.
    ',
    'button_header' => 'Register',


    'header_card_one' => 'How To Get Token',
    'desc_header_search' => '1. Search Reseller',
    'desc_header_contact' => '2. Contact Phone Number',


    'header_card_two' => 'How To Get Reseller',
    'desc_header_admin' => '1. Contact Phone Number Admin',
    'desc_header_format' => '2. Send Format Whatsapp (rbm_reseller # namaowner # namatoko # no.telepon # alamat)',


    'header_feature' => 'Mobi App Feature For Owner Store',


    'feature_desc_home' => 'Monthly Profit',
    'feature_card_one' => 'Report Daily',
    'feature_desc_service' => 'Report Profit Service',
    'feature_desc_phone' => 'Report Profit Handphone',
    'feature_desc_part' => 'Report Profit Sparepart',
    'feature_card_two' => 'Employee',
    'feature_desc_admin' => 'Manage Admin',
    'feature_card_three' => 'Management Store',
    'feature_desc_store' => 'Percentage, Banner, Warranty',


    'header_started' => 'Getting Started',


    'header_footer' => 'More Info',
);
return ($newdata);


// ===========================================================================
?>