<?php 
// indonesia
$newdata = array (
    'head_reseller_one' => 'Alamat',
    'head_reseller_two' => 'Telepon',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_reseller_one' => 'Address',
    'head_reseller_two' => 'Number',
);
return ($newdata);


// ===========================================================================
?>