<?php 
// indonesia
$newdata = array (
    'warranty_all_one' => 'NAMA KONSUMEN',
    'warranty_all_two' => 'TANGGAL KADALUARSA',
);
return ($newdata);

// Inggris
$newdata = array (
    'warranty_all_one' => 'CUSTOMER NAME',
    'warranty_all_two' => 'DATE EXPIRED',
);
return ($newdata);


// ===========================================================================
?>