<?php 
// indonesia
$newdata = array (
    'service_profit_report' => 'PEMASUKKAN KESELURUHAN',


    'search_tech' => 'CARI BRDASARKAN TEKNISI', 
    'search_label_tech' => 'pilih teknisi', 


    'button_report_service' => 'Cetak Laporan', 


    'head_report_one' => 'TANGGAL AMBIL', 
    'head_report_two' => 'KONSUMEN', 
    'head_report_three' => 'MEREK', 
    'head_report_four' => 'KERUSAKAN', 
    'head_report_five' => 'LABA', 
);
return ($newdata);

// Inggris
$newdata = array (
    'service_profit_report' => 'OVERALL INCOME',


    'search_tech' => 'SEARCH BY TECHNICIAN',
    'search_label_tech' => 'Select Techncian',  


    'button_report_service' => 'Print', 


    'head_report_one' => 'DATE OUT', 
    'head_report_two' => 'CUSTOMER', 
    'head_report_three' => 'BRAND', 
    'head_report_four' => 'DAMAGE', 
    'head_report_five' => 'PROFIT', 
);
return ($newdata);


// ===========================================================================
?>