<?php 
// indonesia
$newdata = array (
    'info_banner' => 'Rekomendasi width: 1200px X height: 300px
    format banner : jpg, png, jpeg
    size maksimal 2Mb
    Jika size dan format tidak sesuai dengan ketentuan, maka banner akan otomatis default ', 


    'subhead_warranty' => 'Banner Garansi', 
    'subhead_Product' => 'Banner Produk', 
);
return ($newdata);

// Inggris
$newdata = array (
    'info_banner' => 'Recomendation width: 1200px x height: 300px
    Allow format file : jpg, png, jpeg
    Maximum size 2Mb
    If in addition to the above format, use default', 


    'subhead_warranty' => 'Banner Warranty', 
    'subhead_Product' => 'Banner Product', 
);
return ($newdata);


// ===========================================================================
?>