<?php 
// indonesia
$newdata = array (
    'phone_spending' => 'PENGELUARAN',
    'income_phone' => 'PEMASUKKAN PERBULAN',


    'add_phone_head' => 'Tambah Handphone',
    'add_label_merk' => 'Merek',
    'add_label_color' => 'Warna',
    'add_label_condition' => 'Kondisi',
    'select_label_condition' => 'Kondisi Handphone',
    'add_label_purchase' => 'Harga Beli',
    'add_label_price' => 'Harga Beli',
    'add_label_desc' => 'Catatan',
    'add_label_img' => 'Foto Handphone',
    'add_button_handphone' => 'Tambah',


    'button_phone_one' => 'Terjual',


    'head_phone_one' => 'MEREK',
    'head_phone_two' => 'HARGA BELI',
    'head_phone_three' => 'HARGA JUAL',
    'head_phone_four' => 'KONSUMEN',
);
return ($newdata);

// Inggris
$newdata = array (
    'phone_spending' => 'SPENDING PHONE',
    'income_phone' => 'INCOME MONTHLY',


    'add_phone_head' => 'Add Handphone',
    'add_label_merk' => 'Merk',
    'add_label_color' => 'Color',
    'add_label_condition' => 'Condition',
    'select_label_condition' => 'Handphone Condition',
    'add_label_purchase' => 'Purchase Price',
    'add_label_price' => 'Selling Price',
    'add_label_desc' => 'Description',
    'add_label_img' => 'Image',
    'add_button_handphone' => 'Add',


    'button_phone_one' => 'SOLD',


    'head_phone_one' => 'MERK',
    'head_phone_two' => 'PURCHASE PRICE',
    'head_phone_three' => 'SELLING PRICE',
    'head_phone_four' => 'CUSTOMER',
);
return ($newdata);


// ===========================================================================
?>