<?php 
// indonesia
$newdata = array (
    'service_profit_daily' => 'Laba Service',
    'sparepart_profit_daily' => 'Laba Sparepart', 
    'handphone_profit_daily' => 'Laba Handphone',
    'all_profit_daily' => 'Total Laba', 


    'head_service_daily' => 'LAPORAN SERVICE TANGGAL', 
    'head_sparepart_daily' => 'LAPORAN PENJUALAN SPAREPART TANGGAL', 
    'head_handphone_daily' => 'LAPORAN PENJUALAN HANDPHONE TANGGAL', 


    'head_daily_one' => 'TANGGAL AMBIL', 
    'head_daily_two' => 'KONSUMEN', 
    'head_daily_three' => 'MEREK', 
    'head_daily_four' => 'KERUSAKAN', 
    'head_daily_five' => 'LABA', 
    'head_daily_six' => 'TANGGAL JUAL', 
    'head_daily_seven' => 'NAMA SPAREPART', 
    'head_daily_eight' => 'JUMLAH', 
    'head_daily_nine' => 'HARGA MODAL', 
    'head_daily_ten' => 'HARGA JUAL', 
    'head_daily_eleven' => 'HARGA', 
);
return ($newdata);

// Inggris
$newdata = array (
    'service_profit_daily' => 'Service profit',
    'sparepart_profit_daily' => 'Sparepart Profit', 
    'handphone_profit_daily' => 'Handphone Profit',
    'all_profit_daily' => 'Total Profit', 


    'head_service_daily' => 'REPORT SERVICE BY DATE', 
    'head_sparepart_daily' => 'REPORT SPAREPART SELL BY DATE', 
    'head_handphone_daily' => 'REPORT HANDPHONE SELL BY DATE', 


    'head_daily_one' => 'DATE OUT', 
    'head_daily_two' => 'CUSTOMER', 
    'head_daily_three' => 'BRAND', 
    'head_daily_four' => 'DAMAGE', 
    'head_daily_five' => 'PROFIT', 
    'head_daily_six' => 'DATE SELL', 
    'head_daily_seven' => 'SPAREPART NAME', 
    'head_daily_eight' => 'QTY', 
    'head_daily_nine' => 'CAPITAL PRICE', 
    'head_daily_ten' => 'SELLING PRICE', 
    'head_daily_eleven' => 'PRICE', 
);
return ($newdata);


// ===========================================================================
?>