<?php 
// indonesia
$newdata = array (
    'sidebar_part_tech' => 'Part Teknisi',
    'sidebar_warranty' => 'Garansi',
    'sidebar_sell_phone' => 'Penjualan Handphone',
    'sidebar_product' => 'Produk',
    'sidebar_category' => 'Kategori',
    'sidebar_sell' => 'Penjualan',
    'sidebar_cash' => 'Kas',
    'sidebar_store' => 'Pengeluaran Toko',
    'sidebar_report' => 'Laporan',
    'sidebar_report_daily' => 'Harian',
    'sidebar_promotion' => 'Promo',
    'sidebar_testimonial' => 'Testimoni',
    'sidebar_setting_percentage' => 'Persentase',
    'sidebar_setting_store' => 'Toko',
    'sidebar_setting_credit' => 'Pulsa',
    'sidebar_account_out' => 'Keluar',
);
return ($newdata);

// Inggris
$newdata = array (
    'sidebar_part_tech' => 'Part Technician Used',
    'sidebar_warranty' => 'Warranty',
    'sidebar_sell_phone' => 'Handphone Sell',
    'sidebar_product' => 'Product',
    'sidebar_category' => 'Category',
    'sidebar_sell' => 'Sell',
    'sidebar_cash' => 'Cash',
    'sidebar_store' => 'Store Expenses',
    'sidebar_report' => 'Report',
    'sidebar_report_daily' => 'Daily',
    'sidebar_promotion' => 'Promotion',
    'sidebar_testimonial' => 'Testimonial',
    'sidebar_setting_percentage' => 'Percentage',
    'sidebar_setting_store' => 'Store',
    'sidebar_setting_credit' => 'Credit',
    'sidebar_account_out' => 'Logout',
);
return ($newdata);


// ===========================================================================
?>