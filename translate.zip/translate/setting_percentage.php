<?php 
// indonesia
$newdata = array (
    'head_percentage' => 'Persentase Teknisi', 
);
return ($newdata);

// Inggris
$newdata = array (
    'head_percentage' => 'Percentage Techncian', 
);
return ($newdata);


// ===========================================================================
?>