<?php 
// indonesia
$newdata = array (
    'handphone_profit_report' => 'PEMASUKKAN KESELURUHAN',
    'handphone_profitall_report' => 'LABA KESELURUHAN',


    'button_report_handphone' => 'Cetak Laporan', 


    'head_handphone_one' => 'TANGGAL', 
    'head_handphone_two' => 'KONSUMEN', 
    'head_handphone_three' => 'HARGA', 
    'head_handphone_four' => 'LABA', 
);
return ($newdata);

// Inggris
$newdata = array (
    'handphone_profit_report' => 'OVERALL INCOME',
    'handphone_profitall_report' => 'PROFIT ALLTIME',


    'button_report_handphone' => 'Print', 


    'head_handphone_one' => 'DATE', 
    'head_handphone_two' => 'CUSTOMER', 
    'head_handphone_three' => 'AMOUNT', 
    'head_handphone_four' => 'PROFIT', 
);
return ($newdata);


// ===========================================================================
?>