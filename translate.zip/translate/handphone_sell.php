<?php 
// indonesia
$newdata = array (
    'head_phone_sell' => 'PENJUALAN HANDPHONE',


    'subhead_one' => 'Tanggal',
    'subhead_two' => 'Masa Garansi',
    'subhead_three' => 'Kasir',
    'subhead_four' => 'Konsumen',
   
);
return ($newdata);

// Inggris
$newdata = array (
    'head_phone_sell' => 'Handphone Sell',

    
    'subhead_one' => 'Date',
    'subhead_two' => 'Expired Warranty',
    'subhead_three' => 'Cashier',
    'subhead_four' => 'Customer',
);
return ($newdata);


// ===========================================================================
?>