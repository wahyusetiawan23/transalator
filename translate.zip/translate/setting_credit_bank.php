<?php 
// indonesia
$newdata = array (
    'head_add_bank' => 'Tambah Bank', 
    'label_bank_name' => 'Nama Owner',
    
    'add_bank_head' => 'Tambah Bank',
    'add_bank_name' => 'Nama Bank',
    'add_name_owner' => 'Nama Owner',

    'button_add_bank' => 'Tambah',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_add_bank' => 'Add Bank', 
    'label_bank_name' => 'Name Owner',
    
    'add_bank_head' => 'Add Bank',
    'add_bank_name' => 'Name Bank',
    'add_name_owner' => 'Name Owner',  

    'button_add_bank' => 'Add',
);
return ($newdata);


// ===========================================================================
?>