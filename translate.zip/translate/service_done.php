<?php 
// indonesia
$newdata = array (

    'service_proccess' => 'Proses Selanjutnya',
    'add_date_proccess' => 'Tanggal',
    'add_tech_proccess' => 'Kasir',


    'service_sparepart_head' => 'Formulir unuk service tidak menggunakan sparepart',
    'not_use_desc' => 'Deskripsi',
    'button_not_sparepart' => 'Simpan',


    'service_sparepart_used' => 'Formulir untuk service menggunakan sparepart',
    'sparepart_instore' => 'Sparepart Dalam Toko',

    
    'sparepart_outstore' => 'Sparepart Luar Toko',
    'sparepart_outstore_label' => 'Harga',


    'combo_outstore' => 'Menggunakan Kas Toko (Balance:)',


    'button_use_sparepart' => 'Simpan',
);
return ($newdata);

// Inggris
$newdata = array (
    'service_proccess' => 'Next Proccess',
    'add_date_proccess' => 'Date',
    'add_tech_proccess' => 'Cashier',


    'service_sparepart_head' => 'Form for service not using sparepart    ',
    'not_use_desc' => 'Description',
    'button_not_sparepart' => 'Save',


    'service_sparepart_used' => 'Form for service using sparepart',
    'sparepart_instore' => 'Sparepart in store',

    
    'sparepart_outstore' => 'Sparepart out store',
    'sparepart_outstore_label' => 'Price',


    'combo_outstore' => 'Using Cash Store (Balance:)',


    'button_use_sparepart' => 'Save',
);
return ($newdata);


// ===========================================================================
?>