<?php 
// indonesia
$newdata = array (
    'sparapart_store_month' => 'SPAREPART TOKO PERBULAN',
    'sparapart_outstore_month' => 'SPAREPART LUAR PERBULAN',


    'use_tech' => 'Menggunakan',
    'notuse_tech' => 'Tidak Menggunakan',
    'outstore_tech' => 'Sparepart Luar',


    'part_tech_one' => 'TANGGAL BAWA',
    'part_tech_two' => 'NAMA TEKNISI',
    'part_tech_three' => 'SPAREPART',
    'part_tech_four' => 'HARGA',
    'part_tech_five' => 'JUMLAH',
    'part_tech_six' => 'DESKRIPSI',

    'part_tech_seven' => 'Konsumen',
    'part_tech_eight' => 'Merek',
    'part_tech_nine' => 'Tipe',
    'part_tech_ten' => 'Kerusakan',
    'part_tech_eleven' => 'Harga',


);
return ($newdata);

// Inggris
$newdata = array (
    'sparapart_store_month' => 'SPAREPART IN STORE MONTHLY',
    'sparapart_outstore_month' => 'SPAREPART OUT STORE MONTHLY',


    'use_tech' => 'USED',
    'notuse_tech' => 'NOT USED',
    'outstore_tech' => 'OUT STORE',


    'part_tech_one' => 'DATE',
    'part_tech_two' => 'TECHNICIAN',
    'part_tech_three' => 'SPAREPART',
    'part_tech_four' => 'PRICE',
    'part_tech_five' => 'QTY',
    'part_tech_six' => 'DESCRIPTION',

    'part_tech_seven' => 'Customer',
    'part_tech_eight' => 'Merk',
    'part_tech_nine' => 'Type',
    'part_tech_ten' => 'Damage',
    'part_tech_eleven' => 'Price',

);
return ($newdata);


// ===========================================================================
?>