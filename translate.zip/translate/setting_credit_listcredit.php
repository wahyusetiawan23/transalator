<?php 
// indonesia
$newdata = array (
    'head_add_listcredit' => 'Tambah List', 

    'table_listcredit_one' => 'Saldo',
    'table_listcredit_two' => 'Harga', 
    
    'add_listcredit_head' => 'Tambah Pulsa',
    'add_listcredit_select' => 'Pilih Provider',
    'add_listcredit_balance' => 'Saldo',
    'add_listcredit_price' => 'Harga',

    'button_add_list' => 'Tambah',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_add_listcredit' => 'Add List', 

    'table_listcredit_one' => 'Balance',
    'table_listcredit_two' => 'Price', 
    
    'add_listcredit_head' => 'Add Credit',
    'add_listcredit_select' => 'Select Provider',
    'add_listcredit_balance' => 'Balance',
    'add_listcredit_price' => 'Price',

    'button_add_list' => 'Add',
);
return ($newdata);


// ===========================================================================
?>