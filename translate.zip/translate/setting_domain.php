<?php 
// indonesia
$newdata = array (
    'info_domain_alert' => 'Sebelum setting di rumahweb, isi terlebih dahulu (jika belum mengisi) form domain di atas.', 

    'info_domain_one' => 'silahkan kunjungi link Disini! untuk tutorial', 

    'info_domain_two' => 'Hal yang harus diperhatikan di rumahweb
    1. untuk Destination : https://konterhp.id/Toko/DEMO
    2. untuk URL Masking di enable kan saja ( yes ).', 
);
return ($newdata);

// Inggris
$newdata = array (
    'info_domain_alert' => 'Before setting up at Rumah Web, first fill out (if you havent already filled in) the domain form above.', 

    'info_domain_one' => 'please visit the link here! for tutorial', 

    'info_domain_two' => 'Things that must be considered in rumahweb
    1. for Destination : https://rbm-borneo.com/Store/propam
    2. for URL Masking enable ( yes ).', 
);
return ($newdata);


// ===========================================================================
?>