<?php 
// indonesia
$newdata = array (
    'header_cat' => 'Kategori',


    'add_cat_head' => 'Tambah Kategori',
    'add_cat_name' => 'Nama Kategori',
    'add_cat_image' => 'Foto',
    'button_add_cat' => 'Tambah', 


    'cat_tab_one' => 'NAMA',
    'cat_tab_two' => 'FOTO',
);
return ($newdata);

// Inggris
$newdata = array (
    'header_cat' => 'Category',


    'add_cat_head' => 'Add Category',
    'add_cat_name' => 'Category Name',
    'add_cat_image' => 'Image',
    'button_add_cat' => 'Add', 


    'cat_tab_one' => 'NAME',
    'cat_tab_two' => 'IMAGEs',
);
return ($newdata);


// ===========================================================================
?>