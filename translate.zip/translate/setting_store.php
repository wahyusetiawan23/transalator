<?php 
// indonesia
$newdata = array (
    'head_edit_store' => 'Edit Toko', 
    'label_name_store' => 'Nama Toko', 
    'label_address_store' => 'Alamat', 
);
return ($newdata);

// Inggris
$newdata = array (
    'head_edit_store' => 'Edit Store', 
    'label_name_store' => 'Store Name', 
    'label_address_store' => 'Address', 
);
return ($newdata);


// ===========================================================================
?>