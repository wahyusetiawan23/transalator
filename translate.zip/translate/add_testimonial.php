<?php 
// indonesia
$newdata = array (
    'add_testi' => 'Testimoni',


    'head_testi_add' => 'Tambah Testimoni', 
    'label_add_one' => 'Nama Konsumen',
    'label_add_two' => 'Foto Testimoni',  
    'button_add_testi' => 'Tambah', 


    'head_testi' => 'NAMA KONSUMEN', 
);
return ($newdata);

// Inggris
$newdata = array (
    'add_testi' => 'Testimoni',


    'head_testi_add' => 'Add Testimonial', 
    'label_add_testi' => 'Name Customer',
    'label_add_testi' => 'Image Testimonial',  
    'button_add_testi' => 'Add',


    'head_testi' => 'NAME CUSTOMER', 
);
return ($newdata);


// ===========================================================================
?>