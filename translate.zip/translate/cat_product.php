<?php 
// indonesia
$newdata = array (
    'header_prod' => 'Produk',


    'add_prod_head' => 'Tambah Produk',
    'add_prod_code' => 'Kode Produk',
    'add_prod_name' => 'Nama Produk',
    'add_prod_stock' => 'Stok',
    'add_prod_capital' => 'Harga Modal',
    'add_prod_store' => 'Harga Toko',
    'add_prod_sell' => 'Harga Jual',
    'add_prod_category' => 'Kategori',
    'add_prod_img' => 'Foto Produk',
    'button_add_prod' => 'Tambah',


    'prod_tab_one' => 'NAMA',
    'prod_tab_two' => 'KATEGORI',
    'prod_tab_three' => 'STOK',
    'prod_tab_four' => 'HARGA MODAL',
    'prod_tab_five' => 'HARGA TOKO',
    'prod_tab_six' => 'HARGA JUAL',
);
return ($newdata);

// Inggris
$newdata = array (
    'header_prod' => 'Product',


    'add_prod_head' => 'Add Product',
    'add_prod_code' => 'Code Product',
    'add_prod_name' => 'Product Name',
    'add_prod_stock' => 'Stock',
    'add_prod_capital' => 'Capital Price',
    'add_prod_store' => 'Store Price',
    'add_prod_sell' => 'Selling Price',
    'add_prod_category' => 'Category',
    'add_prod_img' => 'Image',
    'button_add_prod' => 'Adds',


    'prod_tab_one' => 'NAME',
    'prod_tab_two' => 'CATEGORY',
    'prod_tab_three' => 'STOCK',
    'prod_tab_four' => 'CAPITAL PRICE',
    'prod_tab_five' => 'STORE PRICE',
    'prod_tab_six' => 'SELLING PRICE',
);
return ($newdata);


// ===========================================================================
?>