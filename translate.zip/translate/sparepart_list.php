<?php 
// indonesia
$newdata = array (
    'sparepart_daily' => 'PEMASUKAN HARI INI',
    'sparepart_monthly' => 'PEMASUKKAN PERBULAN',


    'head_sparepart_one' => 'TANGGAL',
    'head_sparepart_two' => 'KONSUMEN',
    'head_sparepart_three' => 'NAMA SPAREPART',
    'head_sparepart_four' => 'JUMLAH',
);
return ($newdata);

// Inggris
$newdata = array (
    'sparepart_daily' => 'Income Daily',
    'sparepart_monthly' => 'Income Monthly',

    
    'head_sparepart_one' => 'DATE',
    'head_sparepart_two' => 'CUSTOMER',
    'head_sparepart_three' => 'SPAREPART NAME',
    'head_sparepart_four' => 'QTY',
);
return ($newdata);


// ===========================================================================
?>