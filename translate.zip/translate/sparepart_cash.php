<?php 
// indonesia
$newdata = array (
    'head_sparepart_cash' => 'Saldo',


    'add_balance_head' => 'Saldo',
    'placeholder_balance' => 'Saldo',


    'button_cash_one' => 'Lunas',
    'button_cash_two' => 'Belum Lunas',


    'header_sparepart_one' => 'TANGGAL',
    'header_sparepart_two' => 'NAMA SPAREPART',
    'header_sparepart_three' => 'HARGA',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_sparepart_cash' => 'Balance',


    'add_balance_head' => 'Balance',
    'placeholder_balance' => 'Balance',


    'button_cash_one' => 'Paid',
    'button_cash_two' => 'Unpaid',


    'header_sparepart_one' => 'DATE',
    'header_sparepart_two' => 'SPAREPART NAME',
    'header_sparepart_three' => 'PRICE',
);
return ($newdata);


// ===========================================================================
?>