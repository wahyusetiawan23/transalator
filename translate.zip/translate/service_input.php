<?php 
// indonesia
$newdata = array (
    'button_service' => 'Tambah Service',


    'service_queue' => 'Antri', 
    'service_proccess' => 'Proses',
    'service_done' => 'Selesai', 
    'service_cancel' => 'Batal', 
    'service_taken' => 'Diambil', 


    'service_add_head' => 'Service Masuk',
    'add_date_serv' => 'Tanggal',
    'add_cashier_serv' => 'Kasir',


    'customer_add_head' => 'Konsumen',
    'add_customer_serv' => 'Nama Kunsumen',
    'add_address_serv' => 'Alamat',
    'add_contact_serv' => 'Kontak',


    'spesific_add_head' => 'Spesifikasi Handphone',
    'add_merk_serv' => 'Merek Handphone',
    'add_type_serv' => 'Tipe handphone',

    
    'detail_add_head' => 'Detail Service',
    'add_crash_serv' => 'Kerusakan',
    'add_desc_serv' => 'Deskripsi',
    'add_complet_serv' => 'Kelengkapan',
    'add_tech_serv' => 'Teknisi',
    'select_tech_serv' => 'Pilih Teknisi',
    'add_price_serv' => 'Harga',



    'service_data_one' => 'TANGGAL MASUK',
    'service_data_two' => 'KONSUMEN',
    'service_data_three' => 'TELEPON',
    'service_data_four' => 'MEREK',
    'service_data_five' => 'TIPE',
    'service_data_six' => 'KELENGKAPAN',
    'service_data_seven' => 'KERUSAKAN',
    'service_data_eight' => 'HARGA',
    'service_data_nine' => 'TEKNISI',


);
return ($newdata);

// Inggris
$newdata = array (
    'button_service' => 'Create Service',


    'service_queue' => 'Queue', 
    'service_proccess' => 'Process',
    'service_done' => 'Done', 
    'service_cancel' => 'Cancel', 
    'service_taken' => 'Taken', 


    'service_add_head' => 'Service In',
    'add_date_serv' => 'Date',
    'add_cashier_serv' => 'Cashier',


    'customer_add_head' => 'Customer',
    'add_customer_serv' => 'Customer Name',
    'add_address_serv' => 'Address',
    'add_contact_serv' => 'Contact',


    'spesific_add_head' => 'Phone Spesification',
    'add_merk_serv' => 'Merk Phone',
    'add_type_serv' => 'Type',

    
    'detail_add_head' => 'Detail Service',
    'add_crash_serv' => 'Crash',
    'add_desc_serv' => 'Description',
    'add_complet_serv' => 'Completeness',
    'add_tech_serv' => 'Technician',
    'select_tech_serv' => 'Select Technician',
    'add_price_serv' => 'Price',


    'service_data_one' => 'DATE IN',
    'service_data_two' => 'CUSTOMER',
    'service_data_three' => 'PHONE',
    'service_data_four' => 'MERK',
    'service_data_five' => 'TYPE',
    'service_data_six' => 'COMPLETENESS',
    'service_data_seven' => 'CRASH',
    'service_data_eight' => 'PRICE',
    'service_data_nine' => 'TECHNICIAN',

);
return ($newdata);


// ===========================================================================
?>