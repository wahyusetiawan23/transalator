<?php 
// indonesia
$newdata = array (
    'head_warranty' => 'Garansi', 
);
return ($newdata);

// Inggris
$newdata = array (
    'head_warranty' => 'Warranty', 
);
return ($newdata);


// ===========================================================================
?>