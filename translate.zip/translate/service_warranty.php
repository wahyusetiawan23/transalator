<?php 
// indonesia
$newdata = array (

    'service_warranty' => 'Service Garansi',
    'warranty_date_alive' => 'Dari Tanggal',
    'warranty_date_exp' => 'Sampai Tanggal',
    'warranty_price_one' => 'Harga Awal',
    'warranty_price_two' => 'Harga Akhir',
);
return ($newdata);

// Inggris
$newdata = array (
    'service_warranty' => 'Warranty Service',
    'warranty_date_alive' => 'Date Alive',
    'warranty_date_exp' => 'Date Expired',
    'warranty_price_one' => 'Price Start',
    'warranty_price_two' => 'Price Final',
);
return ($newdata);


// ===========================================================================
?>