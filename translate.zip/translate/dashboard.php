<?php 
// indonesia
$newdata = array (
    'header_service' => 'Service',
    'service_one' => 'Pengeluaran Sparepart Toko Perbulan',
    'service_two' => 'Pengeluaran Sparepart Toko Perbulan', 
    'income_service' => 'Penghasilan Bulanan',
    'profit_service' => 'Laba', 


    'header_sparepart' => 'Penjualan Sparepart',
    'sparepart_one' => 'Pengeluaran Perbulan',
    'sparepart_two' => 'Pemasukkan Perbulan',
    'sparepart_three' => 'Laba',


    'header_handphone' => 'Penjualan Handphone',
    'handphone_one' => 'Pengeluaran Perbulan',
    'handphone_two' => 'Pemasukkan Perbulan',
    'handphone_three' => 'Laba',


    'header_store' => 'Pengeluaran Toko',
    'spanding_store' => 'Pengeluaran Perbulan',


    'header_profit' => 'Total Laba',
    'profit_one' => 'Laba',


    'header_traffic' => 'Grafik service tahun ini',


    'header_technician' => 'Laba teknisi bulan ini',
    'tech_one' => 'NAMA',
    'tech_two' => 'LABA',
    'tech_three' => 'PERSENTASE',


    'header_use_sparepart' => 'Sparepart service sering terpakai',


    'header_bestseller' => 'Penjualan produk terbanyak',
);
return ($newdata);

// Inggris
$newdata = array (
    'header_service' => 'Service',
    'service_one' => 'Spending Sparepart Store Monthly',
    'service_two' => 'Spending Sparepart out Store Monthly',  
    'income_service' => 'Income Monthly',
    'profit_service' => 'Profit',   


    'header_sparepart' => 'Sparepart sell',
    'sparepart_one' => 'Spending Monthly',
    'sparepart_two' => 'Income Monthly',
    'sparepart_three' => 'Profit',


    'header_handphone' => 'Handphone sell',
    'handphone_one' => 'Spending Monthly',
    'handphone_two' => 'Income Monthly',
    'handphone_three' => 'Profit',


    'header_store' => 'Spending Store',
    'spanding_store' => 'Spending Monthly',


    'header_profit' => 'Total Profit',
    'profit_one' => 'Profit',


    'header_traffic' => 'Service Traffic this year',


    'header_technician' => 'Profit technician this month',
    'tech_two' => 'NAME',
    'tech_three' => 'PROFIT',
    'tech_four' => 'PERCENTAGE',


    'header_use_sparepart' => 'Frequenty Used Sparepart',


    'header_bestseller' => 'Product Best Seller',
);
return ($newdata);


// ===========================================================================
?>