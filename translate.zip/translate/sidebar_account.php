<?php 
// indonesia
$newdata = array (
    'edit_account_img' => 'Foto Owner',
    'edit_account_id' => 'NIK',
    'edit_account_name' => 'Nama',
    'edit_account_phone' => 'No Telepon',
    'edit_account_foto' => 'Foto KTP',
    'edit_account_role' => 'Jabatan',

    'edit_account_info' => 'Format gambar yang di izinkan : jpg, png, jpeg
    Maksismal size : 2MB
    Jika selain format di atas, foto memakai default by Admin',
);
return ($newdata);

// Inggris
$newdata = array (
    'edit_account_img' => 'Image Owner',
    'edit_account_id' => 'Number Identity',
    'edit_account_name' => 'Name',
    'edit_account_phone' => 'Phone',
    'edit_account_foto' => 'Image',
    'edit_account_role' => 'Role',

    'edit_account_info' => 'Allowed image format : jpg, png, jpeg
    Maximum size : 2MB
    If in addition to the format above, the photo uses the default by Admin',
);
return ($newdata);


// ===========================================================================
?>