<?php 
// indonesia
$newdata = array (
    'head_supplier_add' => 'Tambah Invoice',


    'label_supplier_one' => 'Tanggal',
    'label_supplier_two' => 'Nama Supplier',
    'label_supplier_three' => 'Deskripsi',
    'label_supplier_five' => 'Jumlah',
    'label_radio_one' => 'Lunas',
    'label_radio_two' => 'Belum Lunas',


    'button_add_supplier' => 'Tambah',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_supplier_add' => 'Add Invoice',


    'label_supplier_one' => 'Date',
    'label_supplier_two' => 'Supplier Name',
    'label_supplier_three' => 'Description',
    'label_supplier_five' => 'Amount',
    'label_radio_one' => 'Paid',
    'label_radio_two' => 'Unpaid',

    
    'button_add_supplier' => 'Add',
);
return ($newdata);


// ===========================================================================
?>