<?php 
// indonesia
$newdata = array (
    'expenses_daily' => 'PENGELUARAN PER-HARI',
    'expenses_monthly' => 'PENGELUARAN PER-BULAN',


    'head_expenses' => 'PENGELUARAN',


    'add_head_expenses' => 'Tambah Pengeluaran',
    'add_name_expenses' => 'Nama',
    'add_date_expenses' => 'Tanggal',
    'add_amount_expenses' => 'Jumlah',
    'add_desc_expenses' => 'Deskripsi',
    'button_expenses_add' => 'Tambah',


    'head_expenses_one' => 'NAMA',
    'head_expenses_two' => 'TANGGAL',
    'head_expenses_three' => 'HARGA',
    'head_expenses_four' => 'CATATAN',
);
return ($newdata);

// Inggris
$newdata = array (
    'expenses_daily' => 'Daily',
    'expenses_monthly' => 'Monthly',


    'head_expenses' => 'Expenses',


    'add_head_expenses' => 'Add Expenses',
    'add_name_expenses' => 'Name',
    'add_date_expenses' => 'Date',
    'add_amount_expenses' => 'Amount',
    'add_desc_expenses' => 'Description',
    'button_expenses_add' => 'Add',


    'head_expenses_one' => 'NAME',
    'head_expenses_two' => 'DATE',
    'head_expenses_three' => 'AMOUNT',
    'head_expenses_four' => 'DESCRIPTION',
);
return ($newdata);


// ===========================================================================
?>