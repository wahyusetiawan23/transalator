<?php 
// indonesia
$newdata = array (
    'head_add_provider' => 'Tambah Provider', 
    
    'add_provider_head' => 'Tambah Provider',
    'add_provider_name' => 'Nama Provider',
    'add_provider_select' => 'Pilih Provider',

    'button_add_provider' => 'Tambah',
);
return ($newdata);

// Inggris
$newdata = array (
    'head_add_provider' => 'Add Provider', 
    
    'add_provider_head' => 'Add Provider',
    'add_provider_name' => 'Name Provider',
    'add_provider_select' => 'Select Provider',

    'button_add_provider' => 'Add',
);
return ($newdata);


// ===========================================================================
?>