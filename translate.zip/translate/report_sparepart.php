<?php 
// indonesia
$newdata = array (
    'sparepart_profit_report' => 'PEMASUKKAN KESELURUHAN',
    'sparepart_profitall_report' => 'LABA KESELURUHAN',


    'button_report_sparepart' => 'Cetak Laporan', 


    'head_parts_one' => 'TANGGAL', 
    'head_parts_two' => 'KONSUMEN', 
    'head_parts_three' => 'NAMA SPAREPART', 
    'head_parts_four' => 'JUMLAH', 
    'head_parts_five' => 'HARGA MODAL', 
    'head_parts_six' => 'HARGA JUAL', 
    'head_parts_seven' => 'HARGA', 
);
return ($newdata);

// Inggris
$newdata = array (
    'handphone_profit_report' => 'OVERALL INCOME',
    'handphone_profitall_report' => 'PROFIT ALLTIME',


    'button_report_handphone' => 'Print', 


    'head_parts_one' => 'DATE', 
    'head_parts_two' => 'CUSTOMER', 
    'head_parts_three' => 'SPAREPART NAME', 
    'head_parts_four' => 'QTY', 
    'head_parts_five' => 'CAPITAL PRICE', 
    'head_parts_six' => 'SELLING PRICE', 
    'head_parts_seven' => 'PRICE', 
);
return ($newdata);


// ===========================================================================
?>