<?php 
// indonesia
$newdata = array (
    'add_promo' => 'Promo',


    'head_promo_add' => 'Tambah Promo', 
    'label_add_one' => 'Nama Promo',
    'label_add_two' => 'Tanggal Awal',  
    'label_add_three' => 'Tanggal Akhir',  
    'label_add_four' => 'Banner Promo',  
    'button_add_promo' => 'Tambah', 


    'head_promo_one' => 'NAMA', 
    'head_promo_two' => 'DARI TANGGAL', 
    'head_promo_three' => 'SAMPAI TANGGAL', 
);
return ($newdata);

// Inggris
$newdata = array (
    'add_promo' => 'Promotion',


    'head_promo_add' => 'Add Promotion', 
    'label_add_one' => 'Prmotion Name',
    'label_add_two' => 'Date Created',  
    'label_add_three' => 'Date Expired',  
    'label_add_four' => 'Banner Promotion',  
    'button_add_promo' => 'Add', 


    'head_promo_one' => 'NAME', 
    'head_promo_two' => 'DATE CREATED', 
    'head_promo_three' => 'DATE EXPIREDss', 
);
return ($newdata);


// ===========================================================================
?>