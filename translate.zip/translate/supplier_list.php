<?php 
// indonesia
$newdata = array (
    'supplier_daily' => 'PEMBAYARAN BELUM LUNAS HARI INI',
    'supplier_monthly' => 'PEMBAYARAN BELUM LUNAS BULAN INI',


    'head_panel_paid' => 'Lunas',
    'head_panel_unpaid' => 'Belum Lunas',


    'head_supplier_one' => 'TANGGAL',
    'head_supplier_two' => 'NAMA SUPPLIER',
    'head_supplier_three' => 'KETERANGAN',
    'head_supplier_four' => 'JUMLAH',
);
return ($newdata);

// Inggris
$newdata = array (
    'supplier_daily' => 'Payment Unpaid Daily',
    'supplier_monthly' => 'Payment Unpaid Monthly',


    'head_panel_paid' => 'Paid',
    'head_panel_unpaid' => 'Unpaid',


    'head_supplier_one' => 'DATE',
    'head_supplier_two' => 'SUPPLIER NAME',
    'head_supplier_three' => 'DESCRIPTION',
    'head_supplier_four' => 'AMOUNT',
);
return ($newdata);


// ===========================================================================
?>