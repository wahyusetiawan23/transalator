<?php 
// indonesia
$newdata = array (
    'head_admin_add' => 'Tambah Admin', 
    'label_admin_one' => 'Nomor Identitas',
    'label_admin_two' => 'Nama',
    'label_admin_three' => 'Telepon',  
    'label_admin_four' => 'Foto',
    'label_admin_five' => 'Jabatan',
    'button_admin' => 'Tambah', 


    'admin_table_name' => 'NAMA', 
    'admin_table_phone' => 'TELEPON', 
);
return ($newdata);

// Inggris
$newdata = array (
    'head_admin_add' => 'Add Admin', 
    'label_admin_one' => 'Number Identity',
    'label_admin_two' => 'Name',
    'label_admin_three' => 'Phone',  
    'label_admin_four' => 'Image',
    'label_admin_five' => 'Role',
    'button_admin' => 'Add', 


    'admin_table_name' => 'NAME', 
    'admin_table_phone' => 'PHONE',  
);
return ($newdata);


// ===========================================================================
?>