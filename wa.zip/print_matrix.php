<?php 
// indonesia
$newdata = array (
    'print_store' => 'Toko',
    'print_address' => 'Alamat',
    'print_tech' => 'Teknisi',
    'print_check' => 'Cek Service',


    'print_scan_service' => 'Cek Service',
    'print_scan_warranty' => 'Cek Garansi',


    'print_date' => 'Tanggal Service',
    'print_merk' => 'Merek',
    'print_complete' => 'Kelengkapan',
    'print_crash' => 'Kerusakan',
    'print_price' => 'Harga',


    'print_note' => 'Catatan',
    'print_note_one' => 'Garansi Service 7 Hari, berlaku barang sudah diambil.',
    'print_note_two' => 'Slip ini wajib dibawa ketika akan mengambil service.',
    'print_note_three' => 'Garansi berlaku pada kerusakan yang sama.',
    'print_note_four' => 'Cek kembali barang service anda saat penyerahan.',


    'print_cust' => 'Konmsumen',
);
return ($newdata);

// Inggris
$newdata = array (
    'print_store' => 'Store',
    'print_address' => 'Address',
    'print_tech' => 'Technicnan',
    'print_check' => 'Check Service',


    'print_scan_service' => 'Check Service',
    'print_scan_warranty' => 'Check Warranty',


    'print_date' => 'Date Service',
    'print_merk' => 'Brand',
    'print_complete' => 'Completenes',
    'print_crash' => 'Crash',
    'print_price' => 'Price',


    'print_note' => 'Note',
    'print_note_one' => '7 Days service warranty, valid when the goods already taken.',
    'print_note_two' => 'This slip must be brought when going to pick up service.',
    'print_note_three' => 'Warranty applies to the same damage.',
    'print_note_four' => 'Check your service item again when submission.',


    'print_cust' => 'Customer',
);
return ($newdata);


// ===========================================================================
?>