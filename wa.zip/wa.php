<?php 
// indonesia
$newdata = array (
    'wa_notif_head' => 'Notifikasi',
    'wa_notif_title' => 'Service-an kamu dengan nomor invoice',
    'wa_notif_queue' => 'Sudah Masuk kedalam *ANTRIAN* kami. Untuk Proses Tracking, Kamu bisa memantau melalui link dibawah ini. Terimakasih',
    'wa_notif_done' => 'Sudah *SELESAI* diperbaiki teknisi kami, Kamu sudah bisa mengambil ke toko kami. Untuk Proses Tracking, Kamu bisa memantau melalui link dibawah ini. Terimakasih',
    'wa_notif_taken' => 'Sudah di *AMBIL* pada tanggal. Untuk Proses Tracking, Kamu bisa memantau melalui link dibawah ini. Terimakasih',
);
return ($newdata);

// Inggris
$newdata = array (
    'wa_notif_head' => 'Notification',
    'wa_notif_title' => 'Yor service with invoice number',
    'wa_notif_desc' => 'Already entered into our *QUUEE*. For the Tracking Process, you can monitor via the link below. Thank you',
    'wa_notif_done' => 'It has been *FINISHED* repaired by our technician, you can take it to our shop. For the Tracking Process, you can monitor via the link below. Thank you',
    'wa_notif_taken' => 'Already in *TAKE* on date. For the Tracking Process, you can monitor via the link below. Thank you',
);
return ($newdata);


// ===========================================================================
?>