<?php 
// indonesia
$newdata = array (
    'service_print_head' => 'LAPORAN',


    'service_print_start' => 'DARI TANGGAL',
    'service_print_end' => 'SAMPAI TANGGAL',


    'service_head_one' => 'PEMASUKAN',
    'service_head_cust' => 'KONSUMEN',


    'service_head_two' => 'PENGELUARAN SPAREPART TOKO',
    'service_head_date' => 'TANGGAL',
    'service_head_amount' => 'JUMLAH',


    'service_head_three' => 'PENGELUARAN SPAREPART LUAR TOKO',


    'service_head_four' => 'LABA',
    'service_head_store' => 'SPAREPART TOKO',
    'service_head_outstore' => 'SPAREPART LUAR TOKO',
);
return ($newdata);

// Inggris
$newdata = array (
    'service_print_head' => 'REPORT',


    'service_print_start' => 'DATE START',
    'service_print_end' => 'DATE END',


    'service_head_one' => 'INCOME',
    'service_head_cust' => 'CUSTOMERs',


    'service_head_one' => 'SPENDING SPAREPART STORE',
    'service_head_date' => 'DATE',
    'service_head_amount' => 'AMOUNT',


    'service_head_two' => 'SPENDING SPAREPART OUT STORE',


    'service_head_three' => 'PROFIT',
    'service_head_store' => 'SPAREPART STORE',
    'service_head_outstore' => 'SPAREPART OUT STORE',
);
return ($newdata);


// ===========================================================================
?>