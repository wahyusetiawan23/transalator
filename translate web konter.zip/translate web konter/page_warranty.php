<?php 
// indonesia
$newdata = array (
    'page_head_warranty' => 'GARANSI',
    'page_input_warranty' => 'Masukkan No. Invoice',
    'button_product' => 'PRODUK',
    'button_service' => 'CEK SERVICE',


    'result_warranty_head' => 'Hasil Cek Garansi',

    'result_warranty_exp' => 'Kadaluarsa',
    'result_warranty_status' => 'Masa berlaku anda telah kadaluarsa',
);
return ($newdata);

// Inggris
$newdata = array (
    'page_head_warranty' => 'WARRANTY',
    'page_input_warranty' => 'Enter Invoice Number',
    'button_product' => 'PRODUCT',
    'button_service' => 'SERVICE CHECK',


    'result_warranty_head' => 'WARRANTY CHECK RESULT',

    'result_warranty_exp' => 'EXPIRED',
    'result_warranty_status' => 'Ypur validity period has expired',
);
return ($newdata);


// ===========================================================================
?>