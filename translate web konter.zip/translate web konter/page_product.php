<?php 
// indonesia
$newdata = array (
    'page_head_product' => 'PRODUK',
    'page_input_product' => 'Apa yang anda cari..',
    'button_product' => 'CARI',
    'button_service_check' => 'CEK SERVICE',
    'button_warranty_check' => 'CEK GARANSI',


    'page_categories_head' => 'KATEGORI',

    'button_buy_product' => 'Beli',
    'button_stock_product' => 'Stok',
);
return ($newdata);

// Inggris
$newdata = array (
    'page_head_product' => 'PRODUCT',
    'page_input_product' => 'What are you looking for..',
    'button_product' => 'SEACRH',
    'button_service_check' => 'SERVICE CHECK',
    'button_warranty_check' => 'WARRANTY CHECK',


    'page_categories_head' => 'CATEGORY',

    'button_buy_product' => 'Buy',
    'button_stock_product' => 'Stock',
);
return ($newdata);


// ===========================================================================
?>