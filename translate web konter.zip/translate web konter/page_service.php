<?php 
// indonesia
$newdata = array (
    'navbar' => 'Info Lebih Lanjut',


    'page_head_service' => 'CEK SERVICE',
    'page_input_service' => 'Masukkan Nomor Invoice',
    'button_page_one' => 'PRODUK',
    'btton_page_two' => 'CEK GARANSI',


    'page_credit_head' => 'PULSA HANDPHONE',
    'placeholder_input_phone' => 'Masukkan No. Telepon',
    'placeholder_select_nominal' => 'Pilih Nominal',
    'placeholder_select_method' => 'Metode Pembayaran',
    'button_continue' => 'Lanjut',


    'detail_number' => 'No. Telepon',
    'detail_payment' => 'Metode Pembayaran',


    'payment_detail_head' => 'Pembayaran',
    'payment_detail_one' => 'No. Telepon',
    'payment_detail_note' => 'Silahkan lakukan pembayaran sesuai total yang tertera pada nomor diatas, jika sudah segera hubungi admin kami untuk konfirmasi pembayaran',


    'track_name' => 'Nama',
    'track_brand' => 'Merek',
    'track_damage' => 'Kerusakan',


    'track_queue' => 'Antri',
    'track_Proccess' => 'Proses',
    'track_done' => 'Selesai',
    'track_Taken' => 'Ambil',


    'page_testimnial_head' => 'Testimoni',
);
return ($newdata);

// Inggris
$newdata = array (
    'navbar' => 'More Info',


    'page_head_service' => 'SERVICE CHECK',
    'page_input_service' => 'Enter Invoice Number',
    'button_page_one' => 'PRODUCT',
    'button_page_two' => 'WARRANTY CHECK',


    'page_credit_head' => 'PHONE CREDIT',
    'placeholder_input_phone' => 'Input Phone Number',
    'placeholder_select_nominal' => 'Choose Nominal',
    'placeholder_select_method' => 'Payment Method',
    'button_continue' => 'Continue',


    'detail_number' => 'Phone Number',
    'detail_payment' => 'Payment Method',


    'payment_detail_head' => 'Payment',
    'payment_detail_one' => 'Phone Number',
    'payment_detail_note' => 'Please make a payment according to the total listed in the number above, if you have immediately contact our admin to confirm payment',


    'track_name' => 'Name',
    'track_brand' => 'Brand',
    'track_damage' => 'Damage',


    'track_queue' => 'Queue',
    'track_Proccess' => 'Proccess',
    'track_done' => 'Done',
    'track_Taken' => 'Taken',


    'page_testimnial_head' => 'Testimoni',
);
return ($newdata);


// ===========================================================================
?>